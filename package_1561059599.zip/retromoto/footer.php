		<footer class="footer">
	    <div class="container">
		    <div class="row">
			    <div class="col-md-6">
			    	<h3>Контакты</h3>
				    <ul class="footer__contacts list-unstyled">
					    <li><b>Адрес:</b><br>
							г.Харьков, ул.Гаршина 5/7.
						</li>
                        <li><b>Телефон:</b><br>
                        	+38 (099) 948-43-41
	                    </li>
						<li><b>Наш график работы:</b><br>
							‎Ежедневно с 09:00 до 21:00
						</li>
                        <li><b>E-mail:</b><br>
							info@retromoto.kh.ua
						</li>
				    </ul>
					<ul class="elsewhere list-unstyled list-inline">
						
					    <li><a href="https://www.instagram.com/retromoto.kh.ua" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-md-6">
				<h3>Связаться с нами</h3>
				<section class="section">
			
						    <div class="row">
							    <div class="col-md-12">
                                   
                                     <?php echo do_shortcode('[contact-form-7 id="4" title="Контактная форма 1"]'); ?>
			                        
							    </div>
							    
						    </div>
			                
			
				</section>
				</div>
			</div>
		</div>
	</footer>

				<div id="korzinapopup" class="popup">

					<h3>Онлайн бронь</h3>
					<?php echo do_shortcode( '[contact-form-7 id="48" title="Контактная форма онлайн-бронь"]' ); ?>

					

				</div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-52459074-8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-52459074-8');
</script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'Q9dONfP3Dp';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
	<!-- JavaScripts -->
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\jquery-3.1.1.min.js" type="text/javascript"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\plugins.js" type="text/javascript"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\mo.min.js" type="text/javascript"></script>
    <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\common.js" type="text/javascript"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\mo.effect2.init.js" type="text/javascript"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/fancybox\source\jquery.fancybox.pack.js"></script>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js\my.js" type="text/javascript"></script>
</body></html>